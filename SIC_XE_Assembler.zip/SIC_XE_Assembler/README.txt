# SIC-XE-Assembler-with-control-section

1) To start this task Compile the "assembler.cpp" using C++11 version compiler.
Example : $ g++ -std=c++11 assembler.cpp (if you have older version)
	else
	  $ g++ assembler.cpp

2) After successfull compilation Run it with the source file name.
Example : $ ./a.out input.txt

3) It will create the Intermediate program as "intermediate.txt" ans Object program as "output.txt".
